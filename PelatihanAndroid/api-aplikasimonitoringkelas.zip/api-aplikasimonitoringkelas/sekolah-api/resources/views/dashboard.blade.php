@extends('layouts.admin')

@section('title', 'Dashboard')

@section('content')
<div class="dashboard-header">
    <div>
        <h1 class="page-title">
            <i class="fas fa-chart-line"></i>
            Dashboard Overview
        </h1>
        <p class="page-subtitle">Welcome back! Here's what's happening in your school today.</p>
    </div>
</div>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card blue">
        <div class="stat-icon">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-details">
            <div class="stat-number">{{ $total_users }}</div>
            <div class="stat-label">Total Users</div>
        </div>
    </div>

    <div class="stat-card green">
        <div class="stat-icon">
            <i class="fas fa-chalkboard-teacher"></i>
        </div>
        <div class="stat-details">
            <div class="stat-number">{{ $total_guru }}</div>
            <div class="stat-label">Total Teachers</div>
        </div>
    </div>

    <div class="stat-card orange">
        <div class="stat-icon">
            <i class="fas fa-school"></i>
        </div>
        <div class="stat-details">
            <div class="stat-number">{{ $total_kelas }}</div>
            <div class="stat-label">Total Classes</div>
        </div>
    </div>

    <div class="stat-card purple">
        <div class="stat-icon">
            <i class="fas fa-calendar-alt"></i>
        </div>
        <div class="stat-details">
            <div class="stat-number">{{ $total_jadwal }}</div>
            <div class="stat-label">Scheduled Lessons</div>
        </div>
    </div>
</div>

<!-- Data Overview -->
<div class="content-grid">
    <!-- Recent Schedules -->
    <div class="data-card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-calendar-week"></i>
                Recent Schedules
            </h3>
            <a href="{{ route('jadwal.index') }}" class="btn-link">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-body">
            @if($recent_jadwal->count() > 0)
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Subject</th>
                                <th>Teacher</th>
                                <th>Class</th>
                                <th>Day</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($recent_jadwal as $jadwal)
                            <tr>
                                <td><strong>{{ $jadwal->mata_pelajaran }}</strong></td>
                                <td>{{ $jadwal->guru->nama }}</td>
                                <td><span class="badge badge-primary">{{ $jadwal->kelas->nama_kelas }}</span></td>
                                <td><span class="badge badge-blue">{{ $jadwal->hari }}</span></td>
                                <td>{{ substr($jadwal->jam_mulai, 0, 5) }} - {{ substr($jadwal->jam_selesai, 0, 5) }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @else
                <div class="empty-state-small">
                    <i class="fas fa-calendar-times"></i>
                    <p>No schedules found. Start by adding a new schedule!</p>
                </div>
            @endif
        </div>
    </div>

    <!-- Recent Teachers -->
    <div class="data-card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-user-tie"></i>
                Recent Teachers
            </h3>
            <a href="{{ route('guru.index') }}" class="btn-link">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-body">
            @if($recent_guru->count() > 0)
                <div class="list-group">
                    @foreach($recent_guru as $guru)
                    <div class="list-item">
                        <div class="list-avatar">
                            {{ strtoupper(substr($guru->nama, 0, 1)) }}
                        </div>
                        <div class="list-details">
                            <h4>{{ $guru->nama }}</h4>
                            <p><i class="fas fa-id-card"></i> NIP: {{ $guru->nip }} | <i class="fas fa-book"></i> {{ $guru->mata_pelajaran }}</p>
                        </div>
                        <span class="badge badge-pink">{{ $guru->jenis_kelamin }}</span>
                    </div>
                    @endforeach
                </div>
            @else
                <div class="empty-state-small">
                    <i class="fas fa-user-times"></i>
                    <p>No teachers found. Start by adding a new teacher!</p>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection
