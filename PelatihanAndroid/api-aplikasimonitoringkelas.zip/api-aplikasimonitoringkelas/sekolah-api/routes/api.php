<?php

use App\Http\Controllers\Api\TaskController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Authentication Routes
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/user', function (Request $request) {
        return $request->user();
    });
    Route::post('/logout', [AuthController::class, 'logout']);
});

// Public API Routes (untuk development, nanti bisa ditambah auth middleware)
Route::apiResource('users', UserController::class);
Route::apiResource('tasks', TaskController::class);

// Jadwal API Routes
Route::get('/jadwals', [JadwalController::class, 'apiIndex']);
Route::post('/jadwals', [JadwalController::class, 'apiStore']);
Route::get('/jadwals/{id}', [JadwalController::class, 'apiShow']);
Route::put('/jadwals/{id}', [JadwalController::class, 'apiUpdate']);
Route::delete('/jadwals/{id}', [JadwalController::class, 'apiDestroy']);
