<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // Create admin user
        User::updateOrCreate(
            ['email' => 'admin@smkn2.sch.id'],
            [
                'nama' => 'Administrator',
                'password' => Hash::make('password'),
                'role' => 'admin',
            ]
        );

        // Create other test users
        User::updateOrCreate(
            ['email' => 'siswa@smkn2.sch.id'],
            [
                'nama' => 'Siswa Test',
                'password' => Hash::make('password'),
                'role' => 'siswa',
            ]
        );

        User::updateOrCreate(
            ['email' => 'guru@smkn2.sch.id'],
            [
                'nama' => 'Guru Test',
                'password' => Hash::make('password'),
                'role' => 'kurikulum',
            ]
        );
    }
}
