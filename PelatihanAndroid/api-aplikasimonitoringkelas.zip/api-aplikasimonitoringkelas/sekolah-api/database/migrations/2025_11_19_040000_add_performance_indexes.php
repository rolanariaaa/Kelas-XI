<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Add indexes to users table
        Schema::table('users', function (Blueprint $table) {
            $table->index('email');
            $table->index('role');
            $table->index('created_at');
        });

        // Add indexes to guru table
        Schema::table('guru', function (Blueprint $table) {
            $table->index('nama');
            $table->index('nip');
            $table->index('mata_pelajaran');
        });

        // Add indexes to kelas table
        Schema::table('kelas', function (Blueprint $table) {
            $table->index('nama_kelas');
            $table->index('tingkat');
        });

        // Add indexes to jadwal table
        Schema::table('jadwal', function (Blueprint $table) {
            $table->index('kelas_id');
            $table->index('guru_id');
            $table->index('hari');
            $table->index(['hari', 'jam_mulai']); // Composite index for sorting
        });

        // Add indexes to tasks table if exists
        if (Schema::hasTable('tasks')) {
            Schema::table('tasks', function (Blueprint $table) {
                $table->index('user_id');
                $table->index('status');
                $table->index('created_at');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropIndex(['email']);
            $table->dropIndex(['role']);
            $table->dropIndex(['created_at']);
        });

        Schema::table('guru', function (Blueprint $table) {
            $table->dropIndex(['nama']);
            $table->dropIndex(['nip']);
            $table->dropIndex(['mata_pelajaran']);
        });

        Schema::table('kelas', function (Blueprint $table) {
            $table->dropIndex(['nama_kelas']);
            $table->dropIndex(['tingkat']);
        });

        Schema::table('jadwal', function (Blueprint $table) {
            $table->dropIndex(['kelas_id']);
            $table->dropIndex(['guru_id']);
            $table->dropIndex(['hari']);
            $table->dropIndex(['hari', 'jam_mulai']);
        });

        if (Schema::hasTable('tasks')) {
            Schema::table('tasks', function (Blueprint $table) {
                $table->dropIndex(['user_id']);
                $table->dropIndex(['status']);
                $table->dropIndex(['created_at']);
            });
        }
    }
};
