<?php

namespace App\Http\Controllers;

use App\Models\Jadwal;
use App\Models\Kelas;
use App\Models\Guru;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class JadwalController extends Controller
{
    // Web Methods
    public function index()
    {
        $jadwals = Jadwal::with([
            'kelas:id,nama_kelas',
            'guru:id,nama,nip'
        ])
            ->select('id', 'kelas_id', 'guru_id', 'mata_pelajaran', 'hari', 'jam_mulai', 'jam_selesai', 'ruangan')
            ->orderBy('hari', 'asc')
            ->orderBy('jam_mulai', 'asc')
            ->paginate(20);

        return view('jadwal.index', compact('jadwals'));
    }

    public function create()
    {
        $kelas = Kelas::select('id', 'nama_kelas', 'tingkat')
            ->orderBy('nama_kelas', 'asc')
            ->get();
        $gurus = Guru::select('id', 'nama', 'nip', 'mata_pelajaran')
            ->orderBy('nama', 'asc')
            ->get();
        return view('jadwal.create', compact('kelas', 'gurus'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'kelas_id' => 'required|exists:kelas,id',
            'guru_id' => 'required|exists:guru,id',
            'mata_pelajaran' => 'required|string|max:255',
            'hari' => 'required|in:Senin,Selasa,Rabu,Kamis,Jumat,Sabtu',
            'jam_mulai' => 'required',
            'jam_selesai' => 'required',
            'ruangan' => 'nullable|string|max:255',
        ]);

        Jadwal::create($validated);

        return redirect()->route('jadwal.index')->with('success', 'Jadwal berhasil ditambahkan!');
    }

    public function edit(Jadwal $jadwal)
    {
        $kelas = Kelas::select('id', 'nama_kelas', 'tingkat')
            ->orderBy('nama_kelas', 'asc')
            ->get();
        $gurus = Guru::select('id', 'nama', 'nip', 'mata_pelajaran')
            ->orderBy('nama', 'asc')
            ->get();
        return view('jadwal.edit', compact('jadwal', 'kelas', 'gurus'));
    }

    public function update(Request $request, Jadwal $jadwal)
    {
        $validated = $request->validate([
            'kelas_id' => 'required|exists:kelas,id',
            'guru_id' => 'required|exists:guru,id',
            'mata_pelajaran' => 'required|string|max:255',
            'hari' => 'required|in:Senin,Selasa,Rabu,Kamis,Jumat,Sabtu',
            'jam_mulai' => 'required',
            'jam_selesai' => 'required',
            'ruangan' => 'nullable|string|max:255',
        ]);

        $jadwal->update($validated);

        return redirect()->route('jadwal.index')->with('success', 'Jadwal berhasil diupdate!');
    }

    public function destroy(Jadwal $jadwal)
    {
        $jadwal->delete();
        return redirect()->route('jadwal.index')->with('success', 'Jadwal berhasil dihapus!');
    }

    // API Methods
    public function apiIndex()
    {
        $jadwals = Jadwal::with([
            'kelas:id,nama_kelas',
            'guru:id,nama,nip'
        ])
            ->select('id', 'kelas_id', 'guru_id', 'mata_pelajaran', 'hari', 'jam_mulai', 'jam_selesai', 'ruangan')
            ->orderBy('hari', 'asc')
            ->orderBy('jam_mulai', 'asc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $jadwals
        ]);
    }

    public function apiStore(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kelas' => 'required|string|max:255',
            'guru' => 'required|string|max:255',
            'mata_pelajaran' => 'required|string|max:255',
            'hari' => 'required|in:Senin,Selasa,Rabu,Kamis,Jumat,Sabtu',
            'jam_ke' => 'required|string',
            'ruangan' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        // Untuk sementara simpan langsung tanpa relasi
        $jadwal = Jadwal::create([
            'kelas_id' => 1, // default untuk development
            'guru_id' => 1,  // default untuk development
            'mata_pelajaran' => $request->mata_pelajaran,
            'hari' => $request->hari,
            'jam_mulai' => $request->jam_ke,
            'jam_selesai' => $request->jam_ke,
            'ruangan' => $request->ruangan,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Jadwal berhasil ditambahkan',
            'data' => $jadwal
        ], 201);
    }

    public function apiShow($id)
    {
        $jadwal = Jadwal::with(['kelas', 'guru'])->find($id);

        if (!$jadwal) {
            return response()->json([
                'success' => false,
                'message' => 'Jadwal tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $jadwal
        ]);
    }

    public function apiUpdate(Request $request, $id)
    {
        $jadwal = Jadwal::find($id);

        if (!$jadwal) {
            return response()->json([
                'success' => false,
                'message' => 'Jadwal tidak ditemukan'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'mata_pelajaran' => 'sometimes|required|string|max:255',
            'hari' => 'sometimes|required|in:Senin,Selasa,Rabu,Kamis,Jumat,Sabtu',
            'jam_ke' => 'sometimes|required|string',
            'ruangan' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $jadwal->update($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Jadwal berhasil diupdate',
            'data' => $jadwal
        ]);
    }

    public function apiDestroy($id)
    {
        $jadwal = Jadwal::find($id);

        if (!$jadwal) {
            return response()->json([
                'success' => false,
                'message' => 'Jadwal tidak ditemukan'
            ], 404);
        }

        $jadwal->delete();

        return response()->json([
            'success' => true,
            'message' => 'Jadwal berhasil dihapus'
        ]);
    }
}
