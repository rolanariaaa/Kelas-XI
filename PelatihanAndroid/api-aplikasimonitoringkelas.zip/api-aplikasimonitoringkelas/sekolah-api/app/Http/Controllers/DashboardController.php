<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Guru;
use App\Models\Kelas;
use App\Models\Jadwal;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Display the dashboard
     */
    public function index()
    {
        // Simple & fast - hanya query yang dibutuhkan
        $total_users = User::count();
        $total_guru = Guru::count();
        $total_kelas = Kelas::count();
        $total_jadwal = Jadwal::count();

        // Ambil data recent dengan eager loading
        $recent_jadwal = Jadwal::with(['kelas:id,nama_kelas', 'guru:id,nama'])
            ->select('id', 'kelas_id', 'guru_id', 'mata_pelajaran', 'hari', 'jam_mulai', 'jam_selesai')
            ->latest()
            ->take(5)
            ->get();

        $recent_guru = Guru::select('id', 'nama', 'nip', 'mata_pelajaran')
            ->latest()
            ->take(5)
            ->get();

        return view('dashboard', compact('total_users', 'total_guru', 'total_kelas', 'total_jadwal', 'recent_jadwal', 'recent_guru'));
    }
}
